import { Markup } from "telegraf";
import { COMMUNITY_CHAT } from "./config";
import type { Category, Product } from "@workspace/db";

export const mainMenuKeyboard = (isAdmin: boolean) =>
  Markup.inlineKeyboard([
    [
      Markup.button.callback("🛒 Shop", "shop"),
      Markup.button.callback("🧺 My Basket", "basket"),
    ],
    [
      Markup.button.callback("⭐ Reviews", "reviews"),
      Markup.button.callback("❓ FAQ", "faq"),
    ],
    [
      Markup.button.callback("📞 Contact Admin", "support"),
      Markup.button.url("💬 Community", COMMUNITY_CHAT),
    ],
    [
      Markup.button.callback("🌿 Flower Range 🔥", "flower_range"),
      Markup.button.callback("📦 Track Order", "track_order"),
    ],
    [
      Markup.button.url("⚡ POWERED BY TBC MARKET", "https://www.thebotcompany.link/"),
    ],
    ...(isAdmin ? [[Markup.button.callback("👑 Admin Panel", "admin")]] : []),
  ]);

export const shopCategoriesKeyboard = (categories: Category[]) =>
  Markup.inlineKeyboard([
    ...categories.map((c) => [
      Markup.button.callback(`${c.emoji} ${c.name}`, `cat_${c.id}`),
    ]),
    [Markup.button.callback("⬅️ Back", "main")],
  ]);

export const productsKeyboard = (
  products: Product[],
  subcategories: Category[],
  backTarget: string,
) =>
  Markup.inlineKeyboard([
    ...subcategories.map((c) => [
      Markup.button.callback(`📁 ${c.emoji} ${c.name}`, `cat_${c.id}`),
    ]),
    ...products.map((p) => [
      Markup.button.callback(
        `${p.emoji} ${p.name} — £${(p.pricePence / 100).toFixed(2)}${p.unitType === "unit" ? "/unit" : "/g"}${p.inStock ? "" : " ✗"}`,
        `prod_${p.id}`,
      ),
    ]),
    [Markup.button.callback("⬅️ Back", backTarget)],
  ]);

export const productDetailKeyboard = (product: Product) =>
  Markup.inlineKeyboard([
    [
      ...(product.inStock
        ? [Markup.button.callback("🛒 Choose Quantity", `badd_${product.id}`)]
        : [Markup.button.callback("❌ Out of Stock", "noop")]),
      Markup.button.callback("⭐ Reviews", "reviews"),
    ],
    [Markup.button.callback("⬅️ Back", `cat_${product.categoryId}`)],
  ]);

export const quantityKeyboard = (productId: number) =>
  Markup.inlineKeyboard([
    [
      Markup.button.callback("1g", `qts_${productId}_1`),
      Markup.button.callback("2g", `qts_${productId}_2`),
      Markup.button.callback("3g", `qts_${productId}_3`),
      Markup.button.callback("5g", `qts_${productId}_5`),
    ],
    [
      Markup.button.callback("7g", `qts_${productId}_7`),
      Markup.button.callback("10g", `qts_${productId}_10`),
      Markup.button.callback("14g", `qts_${productId}_14`),
      Markup.button.callback("28g", `qts_${productId}_28`),
    ],
    [
      Markup.button.callback("56g", `qts_${productId}_56`),
      Markup.button.callback("112g", `qts_${productId}_112`),
      Markup.button.callback("✏️ Custom", `qtc_${productId}`),
    ],
    [Markup.button.callback("⬅️ Back", `prod_${productId}`)],
  ]);

export const unitsKeyboard = (productId: number) =>
  Markup.inlineKeyboard([
    [
      Markup.button.callback("×1", `qtu_${productId}_1`),
      Markup.button.callback("×2", `qtu_${productId}_2`),
      Markup.button.callback("×3", `qtu_${productId}_3`),
      Markup.button.callback("×5", `qtu_${productId}_5`),
    ],
    [
      Markup.button.callback("×10", `qtu_${productId}_10`),
      Markup.button.callback("×20", `qtu_${productId}_20`),
      Markup.button.callback("✏️ Custom", `qtuc_${productId}`),
    ],
    [Markup.button.callback("⬅️ Back", `prod_${productId}`)],
  ]);

export const basketKeyboard = (hasItems: boolean) =>
  Markup.inlineKeyboard([
    ...(hasItems
      ? [
          [Markup.button.callback("✅ Checkout", "checkout")],
          [Markup.button.callback("🗑️ Clear Basket", "bclr")],
        ]
      : []),
    [Markup.button.callback("🛒 Shop", "shop")],
  ]);

export const paymentKeyboard = () =>
  Markup.inlineKeyboard([
    [Markup.button.callback("✅ I've Sent Payment", "payment_sent")],
    [Markup.button.callback("❌ Cancel Order", "cancel_order")],
  ]);

export const reviewsKeyboard = (filter: number, page: number, filteredTotal: number) => {
  const f = (star: number, label: string) =>
    Markup.button.callback(`${filter === star ? "✅ " : ""}${label}`, `rev_${star}_0`);
  const filterRow = [f(5, "⭐⭐⭐⭐⭐"), f(4, "⭐⭐⭐⭐"), f(3, "⭐⭐⭐"), f(0, "All")];
  const nav = [];
  if (page > 0) nav.push(Markup.button.callback("⬅️ Prev", `rev_${filter}_${page - 1}`));
  if (page < filteredTotal - 1) nav.push(Markup.button.callback("Next ➡️", `rev_${filter}_${page + 1}`));
  return Markup.inlineKeyboard([
    filterRow,
    ...(nav.length ? [nav] : []),
    [Markup.button.callback("⬅️ Back", "main")],
  ]);
};

export const adminKeyboard = () =>
  Markup.inlineKeyboard([
    [
      Markup.button.callback("➕ Add Category", "adm_addcat"),
      Markup.button.callback("📦 Add Product", "adm_addprod"),
    ],
    [
      Markup.button.callback("📋 Pending Orders", "adm_pending"),
      Markup.button.callback("📊 All Orders", "adm_allorders"),
    ],
    [
      Markup.button.callback("🔧 Toggle Stock", "adm_stock"),
      Markup.button.callback("🗑️ Delete Product", "adm_delprod"),
    ],
    [
      Markup.button.callback("🔀 Merge Categories", "adm_merge"),
      Markup.button.callback("🖼️ Edit Image", "adm_setimg"),
    ],
    [
      Markup.button.callback("💬 Support Chats", "adm_support"),
    ],
  ]);

export const adminCategorySelectKeyboard = (categories: Category[], cancelTarget = "admin") =>
  Markup.inlineKeyboard([
    ...categories.map((c) => [
      Markup.button.callback(`${c.emoji} ${c.name}`, `adm_catsel_${c.id}`),
    ]),
    [Markup.button.callback("❌ Cancel", cancelTarget)],
  ]);

export const adminStockKeyboard = (products: Product[]) =>
  Markup.inlineKeyboard([
    ...products.map((p) => [
      Markup.button.callback(
        `${p.inStock ? "✅" : "❌"} ${p.emoji} ${p.name}`,
        `adm_tstock_${p.id}`,
      ),
    ]),
    [Markup.button.callback("⬅️ Back", "admin")],
  ]);

export const verifyOrderKeyboard = (orderId: number) =>
  Markup.inlineKeyboard([
    [Markup.button.callback("✅ Verify Payment", `adm_verify_${orderId}`)],
    [Markup.button.callback("❌ Cancel Order", `adm_cancel_${orderId}`)],
    [Markup.button.callback("⬅️ Pending Orders", "adm_pending")],
  ]);
