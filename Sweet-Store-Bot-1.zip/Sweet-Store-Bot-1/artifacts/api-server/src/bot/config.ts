export const ADMIN_IDS: number[] = (process.env.ADMIN_IDS ?? "")
  .split(",")
  .map((s) => parseInt(s.trim(), 10))
  .filter((n) => !isNaN(n));

export const BTC_ADDRESS =
  process.env.BTC_ADDRESS ??
  "bc1pjy8a949q20s9nraxaw4xvqyr3qmutc76eewrthvy5pjxc8u8yykq93zjnf";

export const COMMUNITY_CHAT =
  process.env.COMMUNITY_CHAT ?? "https://t.me/NLsweetsUK2UK";

export const SHOP_NAME = "✨ UncleTerpenes Shop ✨";

export const isAdmin = (userId: number): boolean =>
  ADMIN_IDS.includes(userId);

export const gbp = (pence: number): string =>
  `£${(pence / 100).toFixed(2)}`;
