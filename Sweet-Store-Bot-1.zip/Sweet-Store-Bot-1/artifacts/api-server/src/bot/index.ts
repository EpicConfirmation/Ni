import { Telegraf, session } from "telegraf";
import type { MyContext, SessionData } from "./types";
import { registerMainHandlers } from "./handlers/main";
import { registerShopHandlers } from "./handlers/shop";
import { registerBasketHandlers } from "./handlers/basket";
import { registerAdminHandlers } from "./handlers/admin";
import { registerReviewHandlers } from "./handlers/reviews";
import { registerSupportHandlers } from "./handlers/support";
import { registerTrackingHandlers } from "./handlers/tracking";
import { logger } from "../lib/logger";

export function createBot(): Telegraf<MyContext> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) throw new Error("TELEGRAM_BOT_TOKEN is required");

  const bot = new Telegraf<MyContext>(token);

  bot.use(
    session({
      defaultSession: (): SessionData => ({ step: "main" }),
    }),
  );

  // Order matters: admin handler must be registered before support/basket
  // so admin text steps are caught first
  registerMainHandlers(bot);
  registerShopHandlers(bot);
  registerAdminHandlers(bot);
  registerSupportHandlers(bot);
  registerTrackingHandlers(bot);
  registerBasketHandlers(bot);
  registerReviewHandlers(bot);

  bot.catch((err, ctx) => {
    logger.error(
      { err, userId: ctx.from?.id, updateType: ctx.updateType },
      "Unhandled bot error",
    );
  });

  return bot;
}

export async function startBot(): Promise<Telegraf<MyContext>> {
  const bot = createBot();
  bot.launch({ dropPendingUpdates: true });
  process.once("SIGINT", () => bot.stop("SIGINT"));
  process.once("SIGTERM", () => bot.stop("SIGTERM"));
  logger.info("Telegram bot started (polling)");
  return bot;
}
