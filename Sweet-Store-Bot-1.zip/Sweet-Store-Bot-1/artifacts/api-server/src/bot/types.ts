import { Context } from "telegraf";

export interface PendingProduct {
  categoryId?: number;
  name?: string;
  pricePence?: number;
  description?: string;
  emoji?: string;
  unitType?: string;
}

export interface PendingCategory {
  name: string;
  emoji: string;
}

export interface SessionData {
  step: string;
  pendingProduct?: PendingProduct;
  pendingCategory?: PendingCategory;
  reviewPage?: number;
  pendingCheckout?: {
    totalPence: number;
    items: Array<{
      productName: string;
      productEmoji: string;
      pricePence: number;
      quantity: number;
      unitType: string;
    }>;
  };
  qtyProductId?: number;
  supportReplyUserId?: number;
  supportReplyChatId?: number;
  pendingMergeSourceId?: number;
  pendingImgProductId?: number;
  pendingShipOrderId?: number;
  pendingTrackName?: string;
}

export interface MyContext extends Context {
  session: SessionData;
}
