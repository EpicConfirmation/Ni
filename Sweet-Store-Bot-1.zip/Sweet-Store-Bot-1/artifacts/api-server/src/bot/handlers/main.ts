import { Telegraf } from "telegraf";
import type { MyContext } from "../types";
import { mainMenuKeyboard } from "../keyboards";
import { isAdmin, SHOP_NAME } from "../config";

export const MAIN_MENU_TEXT = `${SHOP_NAME}
━━━━━━━━━━━━━━━
🕐 Last seen: recently
📦 Ships from: UK → UK
💰 Sales: 3562
💷 Currency: GBP
⭐ Rating: ★4.94 (164)

📅 We ship Monday–Friday. Cut-off for same-day dispatch is 2PM.

📖 Please refer to the FAQ first for any questions — you should find the answers there.

👑 Admins: @UncleTerpene`;

export function registerMainHandlers(bot: Telegraf<MyContext>) {
  bot.start(async (ctx) => {
    ctx.session.step = "main";
    await ctx.reply(MAIN_MENU_TEXT, {
      ...mainMenuKeyboard(isAdmin(ctx.from?.id ?? 0)),
      parse_mode: "HTML",
    });
  });

  bot.action("main", async (ctx) => {
    ctx.session.step = "main";
    await ctx.answerCbQuery();
    try {
      await ctx.editMessageText(MAIN_MENU_TEXT, {
        ...mainMenuKeyboard(isAdmin(ctx.from?.id ?? 0)),
        parse_mode: "HTML",
      });
    } catch {
      await ctx.reply(MAIN_MENU_TEXT, {
        ...mainMenuKeyboard(isAdmin(ctx.from?.id ?? 0)),
        parse_mode: "HTML",
      });
    }
  });

  bot.action("flower_range", async (ctx) => {
    await ctx.answerCbQuery();
    const text = `🌿 <b>Flower Range — ON SALE NOW</b>
━━━━━━━━━━━━━━━
All bud currently on sale!

💰 <b>£140 per oz (£5 per gram)</b>

Whether you want a gram or a full oz, we've got you covered. Premium UK-grown and imported flower, shipped discreet next day.

📦 Tap <b>Shop</b> to browse the full flower range 👇`;
    try {
      await ctx.editMessageText(text, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🛒 Browse Shop", callback_data: "shop" }],
            [{ text: "⬅️ Back", callback_data: "main" }],
          ],
        },
      });
    } catch {
      await ctx.reply(text, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🛒 Browse Shop", callback_data: "shop" }],
            [{ text: "⬅️ Back", callback_data: "main" }],
          ],
        },
      });
    }
  });

  bot.action("faq", async (ctx) => {
    await ctx.answerCbQuery();
    const faqText = `❓ <b>Frequently Asked Questions</b>

<b>How do I order?</b>
Browse the shop, add items to your basket, then checkout and send crypto payment.

<b>What payment methods do you accept?</b>
We accept Bitcoin (BTC) only. The address is shown at checkout.

<b>How long does delivery take?</b>
Next day delivery for orders placed before 2PM Mon–Fri. Orders after 2PM are dispatched the next working day.

<b>Do you ship on weekends?</b>
No — we dispatch Monday to Friday only. Weekend orders are sent out Monday.

<b>Is packaging discreet?</b>
Yes, all orders are sent in plain, discreet packaging with no identifiable markings.

<b>What if my order doesn't arrive?</b>
Contact @UncleTerpene directly with your order number and we'll sort it out.

<b>Can I track my order?</b>
Tracking info is sent once your order has been dispatched. Use the Track Order button on the main menu.`;

    try {
      await ctx.editMessageText(faqText, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "main" }]] },
      });
    } catch {
      await ctx.reply(faqText, { parse_mode: "HTML" });
    }
  });

  bot.action("noop", async (ctx) => {
    await ctx.answerCbQuery("❌ This item is currently out of stock.");
  });
}
