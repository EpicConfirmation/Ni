import { Telegraf } from "telegraf";
import { eq, isNull } from "drizzle-orm";
import type { MyContext } from "../types";
import {
  shopCategoriesKeyboard,
  productsKeyboard,
  productDetailKeyboard,
  quantityKeyboard,
  unitsKeyboard,
} from "../keyboards";
import {
  db,
  categoriesTable,
  productsTable,
  basketItemsTable,
} from "@workspace/db";
import { gbp } from "../config";
import { FAKE_REVIEWS } from "../reviews";

const LATEST_REVIEW = FAKE_REVIEWS[0]!;
const STARS: Record<number, string> = { 5: "⭐⭐⭐⭐⭐", 4: "⭐⭐⭐⭐", 3: "⭐⭐⭐", 2: "⭐⭐", 1: "⭐" };

export function registerShopHandlers(bot: Telegraf<MyContext>) {
  // ── Top-level shop: show root categories ─────────────────────────────────
  bot.action("shop", async (ctx) => {
    await ctx.answerCbQuery();
    const categories = await db
      .select()
      .from(categoriesTable)
      .where(isNull(categoriesTable.parentId))
      .orderBy(categoriesTable.id);

    if (categories.length === 0) {
      try {
        await ctx.editMessageText("🛒 <b>Shop</b>\n\nNo categories yet — check back soon!", {
          parse_mode: "HTML",
        });
      } catch {
        await ctx.reply("🛒 <b>Shop</b>\n\nNo categories yet — check back soon!", {
          parse_mode: "HTML",
        });
      }
      return;
    }

    const text = `🛒 <b>Shop — Choose a Category</b>`;
    try {
      await ctx.editMessageText(text, {
        parse_mode: "HTML",
        ...shopCategoriesKeyboard(categories),
      });
    } catch {
      await ctx.reply(text, {
        parse_mode: "HTML",
        ...shopCategoriesKeyboard(categories),
      });
    }
  });

  // ── Category view: show subcategories + products ──────────────────────────
  bot.action(/^cat_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const catId = parseInt((ctx.match as RegExpMatchArray)[1], 10);

    const [category] = await db
      .select()
      .from(categoriesTable)
      .where(eq(categoriesTable.id, catId));

    if (!category) return;

    const [subcategories, products] = await Promise.all([
      db
        .select()
        .from(categoriesTable)
        .where(eq(categoriesTable.parentId, catId))
        .orderBy(categoriesTable.id),
      db
        .select()
        .from(productsTable)
        .where(eq(productsTable.categoryId, catId))
        .orderBy(productsTable.id),
    ]);

    const backTarget = category.parentId ? `cat_${category.parentId}` : "shop";

    if (subcategories.length === 0 && products.length === 0) {
      try {
        await ctx.editMessageText(
          `${category.emoji} <b>${category.name}</b>\n\nNothing here yet.`,
          {
            parse_mode: "HTML",
            reply_markup: {
              inline_keyboard: [[{ text: "⬅️ Back", callback_data: backTarget }]],
            },
          },
        );
      } catch {
        await ctx.reply(`${category.emoji} <b>${category.name}</b>\n\nNothing here yet.`, {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [[{ text: "⬅️ Back", callback_data: backTarget }]],
          },
        });
      }
      return;
    }

    const text = `${category.emoji} <b>${category.name}</b>`;
    try {
      await ctx.editMessageText(text, {
        parse_mode: "HTML",
        ...productsKeyboard(products, subcategories, backTarget),
      });
    } catch {
      await ctx.reply(text, {
        parse_mode: "HTML",
        ...productsKeyboard(products, subcategories, backTarget),
      });
    }
  });

  // ── Product detail ────────────────────────────────────────────────────────
  bot.action(/^prod_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const prodId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    const [product] = await db
      .select()
      .from(productsTable)
      .where(eq(productsTable.id, prodId));

    if (!product) return;

    const stockStatus = product.inStock ? "✅ In Stock" : "❌ Out of Stock";
    const priceLabel = product.unitType === "unit" ? "per unit" : "per gram";
    const stars = STARS[LATEST_REVIEW.rating] ?? "⭐⭐⭐⭐⭐";

    const text = `${product.emoji} <b>${product.name}</b>
━━━━━━━━━━━━━━━
💷 Price: <b>${gbp(product.pricePence)}</b> ${priceLabel}
📦 Status: ${stockStatus}
🛒 <b>${product.salesCount}</b> sold

${product.description}

━━━━━━━━━━━━━━━
${stars} <i>"${LATEST_REVIEW.text}"</i>
<i>${LATEST_REVIEW.date}</i>`;

    if (product.photoFileId) {
      try { await ctx.deleteMessage(); } catch { /* ignore */ }
      await ctx.replyWithPhoto(product.photoFileId, {
        caption: text,
        parse_mode: "HTML",
        ...productDetailKeyboard(product),
      });
      return;
    }

    try {
      await ctx.editMessageText(text, {
        parse_mode: "HTML",
        ...productDetailKeyboard(product),
      });
    } catch {
      await ctx.reply(text, {
        parse_mode: "HTML",
        ...productDetailKeyboard(product),
      });
    }
  });

  // ── "Add to basket" → show quantity/unit picker ───────────────────────────
  bot.action(/^badd_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const prodId = parseInt((ctx.match as RegExpMatchArray)[1], 10);

    const [product] = await db
      .select()
      .from(productsTable)
      .where(eq(productsTable.id, prodId));

    if (!product || !product.inStock) {
      await ctx.answerCbQuery("❌ Sorry, this item is out of stock.");
      return;
    }

    const isUnit = product.unitType === "unit";
    const priceLabel = isUnit ? "per unit" : "per gram";
    const qtyLabel = isUnit ? "How many units?" : "How many grams?";
    const maxLabel = isUnit ? "up to 20" : "up to 112g";

    const text = `${product.emoji} <b>${product.name}</b>
━━━━━━━━━━━━━━━
💷 <b>${gbp(product.pricePence)}</b> ${priceLabel}

🎚️ <b>${qtyLabel}</b>
Choose a preset or tap ✏️ Custom to enter any amount (${maxLabel}).`;

    const keyboard = isUnit ? unitsKeyboard(prodId) : quantityKeyboard(prodId);

    try {
      await ctx.editMessageText(text, {
        parse_mode: "HTML",
        ...keyboard,
      });
    } catch {
      await ctx.reply(text, {
        parse_mode: "HTML",
        ...keyboard,
      });
    }
  });

  // ── Preset gram quantity selected ──────────────────────────────────────────
  bot.action(/^qts_(\d+)_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const [, prodIdStr, amountStr] = ctx.match as RegExpMatchArray;
    const prodId = parseInt(prodIdStr, 10);
    const amount = parseInt(amountStr, 10);
    await addToBasket(ctx, prodId, amount);
  });

  // ── Preset unit quantity selected ──────────────────────────────────────────
  bot.action(/^qtu_(\d+)_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const [, prodIdStr, amountStr] = ctx.match as RegExpMatchArray;
    const prodId = parseInt(prodIdStr, 10);
    const amount = parseInt(amountStr, 10);
    await addToBasket(ctx, prodId, amount);
  });

  // ── Custom gram quantity ────────────────────────────────────────────────────
  bot.action(/^qtc_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const prodId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    ctx.session.step = "qty_custom";
    ctx.session.qtyProductId = prodId;

    await ctx.reply(
      "✏️ <b>Enter amount in grams</b> (1–112):",
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "❌ Cancel", callback_data: `badd_${prodId}` }]],
        },
      },
    );
  });

  // ── Custom unit quantity ────────────────────────────────────────────────────
  bot.action(/^qtuc_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const prodId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    ctx.session.step = "qty_custom_unit";
    ctx.session.qtyProductId = prodId;

    await ctx.reply(
      "✏️ <b>Enter number of units</b> (1–20):",
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "❌ Cancel", callback_data: `badd_${prodId}` }]],
        },
      },
    );
  });

  // ── Text handler: custom quantity input ───────────────────────────────────
  bot.on("text", async (ctx, next) => {
    const step = ctx.session.step;

    if (step === "qty_custom") {
      const prodId = ctx.session.qtyProductId;
      if (!prodId) return next();

      const raw = ctx.message.text.trim().replace(/g$/i, "");
      const amount = parseInt(raw, 10);

      if (isNaN(amount) || amount < 1 || amount > 112) {
        await ctx.reply("⚠️ Please enter a whole number between 1 and 112:", {
          reply_markup: {
            inline_keyboard: [[{ text: "❌ Cancel", callback_data: `badd_${prodId}` }]],
          },
        });
        return;
      }

      ctx.session.step = "main";
      ctx.session.qtyProductId = undefined;
      await addToBasket(ctx, prodId, amount);
      return;
    }

    if (step === "qty_custom_unit") {
      const prodId = ctx.session.qtyProductId;
      if (!prodId) return next();

      const amount = parseInt(ctx.message.text.trim(), 10);

      if (isNaN(amount) || amount < 1 || amount > 20) {
        await ctx.reply("⚠️ Please enter a whole number between 1 and 20:", {
          reply_markup: {
            inline_keyboard: [[{ text: "❌ Cancel", callback_data: `badd_${prodId}` }]],
          },
        });
        return;
      }

      ctx.session.step = "main";
      ctx.session.qtyProductId = undefined;
      await addToBasket(ctx, prodId, amount);
      return;
    }

    return next();
  });
}

async function addToBasket(ctx: MyContext, prodId: number, quantity: number) {
  const userId = ctx.from?.id;
  if (!userId) return;

  const [product] = await db
    .select()
    .from(productsTable)
    .where(eq(productsTable.id, prodId));

  if (!product || !product.inStock) {
    await ctx.reply("❌ Sorry, this item is now out of stock.");
    return;
  }

  const { and: andOp, eq: eqOp } = await import("drizzle-orm");
  const [existing] = await db
    .select()
    .from(basketItemsTable)
    .where(
      andOp(
        eqOp(basketItemsTable.userId, userId),
        eqOp(basketItemsTable.productId, prodId),
      ),
    );

  if (existing) {
    await db
      .update(basketItemsTable)
      .set({ quantity: existing.quantity + quantity })
      .where(eqOp(basketItemsTable.id, existing.id));
  } else {
    await db.insert(basketItemsTable).values({
      userId,
      productId: prodId,
      quantity,
    });
  }

  const isUnit = product.unitType === "unit";
  const qtyDisplay = isUnit ? `×${quantity}` : `${quantity}g`;
  const totalCost = gbp(product.pricePence * quantity);

  await ctx.reply(
    `✅ <b>${qtyDisplay} ${product.emoji} ${product.name}</b> added to basket!\n💷 ${totalCost}`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "🛒 Add More", callback_data: `badd_${prodId}` },
            { text: "🧺 View Basket", callback_data: "basket" },
          ],
        ],
      },
    },
  );
}
