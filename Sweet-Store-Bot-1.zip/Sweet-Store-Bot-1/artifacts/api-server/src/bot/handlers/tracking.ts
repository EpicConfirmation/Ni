import { Telegraf } from "telegraf";
import type { MyContext } from "../types";
import { ADMIN_IDS } from "../config";
import { mainMenuKeyboard } from "../keyboards";
import { isAdmin, SHOP_NAME } from "../config";

const MAIN_MENU_TEXT = `${SHOP_NAME}
━━━━━━━━━━━━━━━
🕐 Last seen: recently
📦 Ships from: UK → UK
💰 Sales: 3562
💷 Currency: GBP
⭐ Rating: ★4.94 (164)

📅 We ship Monday–Friday. Cut-off for same-day dispatch is 2PM.

📖 Please refer to the FAQ first for any questions — you should find the answers there.

👑 Admins: @UncleTerpene`;

export function registerTrackingHandlers(bot: Telegraf<MyContext>) {
  bot.action("track_order", async (ctx) => {
    await ctx.answerCbQuery();
    ctx.session.step = "track_name";
    try {
      await ctx.editMessageText(
        `📦 <b>Track Your Order</b>

Enter your <b>full name</b> (as used on your delivery address):`,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [[{ text: "❌ Cancel", callback_data: "main" }]],
          },
        },
      );
    } catch {
      await ctx.reply(
        `📦 <b>Track Your Order</b>\n\nEnter your <b>full name</b> (as used on your delivery address):`,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [[{ text: "❌ Cancel", callback_data: "main" }]],
          },
        },
      );
    }
  });

  bot.on("text", async (ctx, next) => {
    const step = ctx.session.step;

    if (step === "track_name") {
      const name = ctx.message.text.trim();
      if (name.length < 2) {
        await ctx.reply("⚠️ Please enter your full name:", {
          reply_markup: { inline_keyboard: [[{ text: "❌ Cancel", callback_data: "main" }]] },
        });
        return;
      }
      ctx.session.pendingTrackName = name;
      ctx.session.step = "track_postcode";
      await ctx.reply(
        `👤 Got it, <b>${name}</b>.\n\nNow enter your <b>postcode</b>:`,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [[{ text: "❌ Cancel", callback_data: "main" }]],
          },
        },
      );
      return;
    }

    if (step === "track_postcode") {
      const postcode = ctx.message.text.trim().toUpperCase();
      const name = ctx.session.pendingTrackName ?? "Unknown";
      const userId = ctx.from?.id;
      const username = ctx.from?.username ? `@${ctx.from.username}` : `ID:${userId}`;

      ctx.session.step = "main";
      ctx.session.pendingTrackName = undefined;

      const adminMsg = `📦 <b>Tracking Request</b>
━━━━━━━━━━━━━━━
👤 Name: <b>${name}</b>
📮 Postcode: <b>${postcode}</b>
🔗 Telegram: ${username}

Reply to this customer with their tracking reference.`;

      for (const adminId of ADMIN_IDS) {
        try {
          await bot.telegram.sendMessage(adminId, adminMsg, { parse_mode: "HTML" });
        } catch { /* admin may not have started bot */ }
      }

      await ctx.reply(
        `✅ <b>Tracking request sent!</b>

📮 Name: <b>${name}</b>
📍 Postcode: <b>${postcode}</b>

Our team will send your tracking information here shortly. This usually happens within a few hours of dispatch.

If you haven't received anything after 24 hours, contact @UncleTerpene directly.`,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [[{ text: "⬅️ Main Menu", callback_data: "main" }]],
          },
        },
      );
      return;
    }

    return next();
  });
}
