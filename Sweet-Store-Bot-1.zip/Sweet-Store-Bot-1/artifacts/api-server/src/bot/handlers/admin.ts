import { Telegraf } from "telegraf";
import { eq, desc, isNull, ne } from "drizzle-orm";
import type { MyContext } from "../types";
import {
  adminKeyboard,
  adminCategorySelectKeyboard,
  adminStockKeyboard,
  verifyOrderKeyboard,
} from "../keyboards";
import {
  db,
  categoriesTable,
  productsTable,
  ordersTable,
  orderItemsTable,
} from "@workspace/db";
import { isAdmin, gbp } from "../config";

function adminGuard(ctx: MyContext): boolean {
  return isAdmin(ctx.from?.id ?? 0);
}

export function registerAdminHandlers(bot: Telegraf<MyContext>) {
  bot.action("admin", async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    ctx.session.step = "admin";
    try {
      await ctx.editMessageText("👑 <b>Admin Panel</b>\n\nWhat would you like to do?", {
        parse_mode: "HTML",
        ...adminKeyboard(),
      });
    } catch {
      await ctx.reply("👑 <b>Admin Panel</b>\n\nWhat would you like to do?", {
        parse_mode: "HTML",
        ...adminKeyboard(),
      });
    }
  });

  // ── Add Category ──────────────────────────────────────────────────────────
  bot.action("adm_addcat", async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    ctx.session.step = "admin_cat_name";
    try {
      await ctx.editMessageText(
        "➕ <b>Add Category</b>\n\nEnter the category name (include an emoji at the start, e.g. <code>🍬 Sweets</code>):",
        {
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: [[{ text: "❌ Cancel", callback_data: "admin" }]] },
        },
      );
    } catch {
      await ctx.reply(
        "➕ <b>Add Category</b>\n\nEnter the category name:",
        {
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: [[{ text: "❌ Cancel", callback_data: "admin" }]] },
        },
      );
    }
  });

  bot.action("adm_cat_toplevel", async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const pending = ctx.session.pendingCategory;
    if (!pending) { ctx.session.step = "admin"; return; }
    await db.insert(categoriesTable).values({ name: pending.name, emoji: pending.emoji, parentId: null });
    ctx.session.step = "admin";
    ctx.session.pendingCategory = undefined;
    await ctx.reply(`✅ Top-level category <b>${pending.emoji} ${pending.name}</b> added!`, {
      parse_mode: "HTML",
      ...adminKeyboard(),
    });
  });

  bot.action("adm_cat_pickparent", async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const categories = await db.select().from(categoriesTable).where(isNull(categoriesTable.parentId)).orderBy(categoriesTable.id);
    if (categories.length === 0) {
      await ctx.answerCbQuery("No top-level categories yet. Create one first.");
      return;
    }
    ctx.session.step = "admin_cat_parent";
    try {
      await ctx.editMessageText("📁 <b>Choose a parent category:</b>", {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            ...categories.map((c) => [{ text: `${c.emoji} ${c.name}`, callback_data: `adm_catpar_${c.id}` }]),
            [{ text: "❌ Cancel", callback_data: "admin" }],
          ],
        },
      });
    } catch {
      await ctx.reply("📁 Choose a parent category:", {
        reply_markup: {
          inline_keyboard: [
            ...categories.map((c) => [{ text: `${c.emoji} ${c.name}`, callback_data: `adm_catpar_${c.id}` }]),
            [{ text: "❌ Cancel", callback_data: "admin" }],
          ],
        },
      });
    }
  });

  bot.action(/^adm_catpar_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const parentId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    const pending = ctx.session.pendingCategory;
    if (!pending) { ctx.session.step = "admin"; return; }
    const [parent] = await db.select().from(categoriesTable).where(eq(categoriesTable.id, parentId));
    await db.insert(categoriesTable).values({ name: pending.name, emoji: pending.emoji, parentId });
    ctx.session.step = "admin";
    ctx.session.pendingCategory = undefined;
    await ctx.reply(
      `✅ Subcategory <b>${pending.emoji} ${pending.name}</b> added under <b>${parent?.emoji} ${parent?.name}</b>!`,
      { parse_mode: "HTML", ...adminKeyboard() },
    );
  });

  // ── Add Product ───────────────────────────────────────────────────────────
  bot.action("adm_addprod", async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const categories = await db.select().from(categoriesTable).orderBy(categoriesTable.id);
    if (categories.length === 0) {
      await ctx.answerCbQuery("⚠️ Add a category first!");
      return;
    }
    ctx.session.step = "admin_prod_cat";
    ctx.session.pendingProduct = {};
    try {
      await ctx.editMessageText("📦 <b>Add Product</b>\n\nChoose a category:", {
        parse_mode: "HTML",
        ...adminCategorySelectKeyboard(categories),
      });
    } catch {
      await ctx.reply("📦 <b>Add Product</b>\n\nChoose a category:", {
        parse_mode: "HTML",
        ...adminCategorySelectKeyboard(categories),
      });
    }
  });

  bot.action(/^adm_catsel_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const catId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    ctx.session.pendingProduct = { ...ctx.session.pendingProduct, categoryId: catId };
    ctx.session.step = "admin_prod_name";
    try {
      await ctx.editMessageText(
        "📦 <b>Add Product</b>\n\nEnter the product name (include an emoji at the start, e.g. <code>🍫 Chocolate Bar</code>):",
        {
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: [[{ text: "❌ Cancel", callback_data: "admin" }]] },
        },
      );
    } catch {
      await ctx.reply("📦 Enter the product name:", {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "❌ Cancel", callback_data: "admin" }]] },
      });
    }
  });

  // ── Unit type selection ───────────────────────────────────────────────────
  bot.action(/^adm_unit_(g|u)$/, async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const unitType = (ctx.match as RegExpMatchArray)[1] === "g" ? "g" : "unit";
    ctx.session.pendingProduct = { ...ctx.session.pendingProduct, unitType };
    ctx.session.step = "admin_prod_desc";
    await ctx.reply(
      `📝 Unit type set to <b>${unitType === "g" ? "Grams ⚖️" : "Units 📦"}</b>\n\nNow enter a short product description:`,
      {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "❌ Cancel", callback_data: "admin" }]] },
      },
    );
  });

  // ── Edit Product Image ────────────────────────────────────────────────────
  bot.action("adm_setimg", async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const products = await db.select().from(productsTable).orderBy(productsTable.id);
    if (products.length === 0) { await ctx.answerCbQuery("No products yet."); return; }
    try {
      await ctx.editMessageText("🖼️ <b>Edit Product Image</b>\n\nChoose a product to set or update its image:", {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            ...products.map((p) => [{
              text: `${p.photoFileId ? "🖼️" : "📷"} ${p.emoji} ${p.name}`,
              callback_data: `adm_imgsel_${p.id}`,
            }]),
            [{ text: "❌ Cancel", callback_data: "admin" }],
          ],
        },
      });
    } catch {
      await ctx.reply("🖼️ Choose a product:", {
        reply_markup: {
          inline_keyboard: products.map((p) => [{ text: `${p.emoji} ${p.name}`, callback_data: `adm_imgsel_${p.id}` }]),
        },
      });
    }
  });

  bot.action(/^adm_imgsel_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const prodId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, prodId));
    if (!product) return;
    ctx.session.step = "admin_prod_img";
    ctx.session.pendingImgProductId = prodId;
    const hasImg = !!product.photoFileId;
    await ctx.reply(
      `🖼️ <b>${product.emoji} ${product.name}</b>\n\n${hasImg ? "This product already has an image. Send a new photo to replace it, or type <code>remove</code> to clear it." : "Send a photo to set the product image."}\n\n<i>Tip: forward or upload directly from your phone.</i>`,
      {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "❌ Cancel", callback_data: "adm_setimg" }]] },
      },
    );
  });

  // ── Delete Product ────────────────────────────────────────────────────────
  bot.action("adm_delprod", async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const products = await db.select().from(productsTable).orderBy(productsTable.id);
    if (products.length === 0) { await ctx.answerCbQuery("No products yet."); return; }
    try {
      await ctx.editMessageText("🗑️ <b>Delete Product</b>\n\nChoose a product to delete:", {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            ...products.map((p) => [{
              text: `${p.emoji} ${p.name}`,
              callback_data: `adm_delsel_${p.id}`,
            }]),
            [{ text: "❌ Cancel", callback_data: "admin" }],
          ],
        },
      });
    } catch {
      await ctx.reply("🗑️ Choose a product to delete:", {
        reply_markup: {
          inline_keyboard: products.map((p) => [{ text: `${p.emoji} ${p.name}`, callback_data: `adm_delsel_${p.id}` }]),
        },
      });
    }
  });

  bot.action(/^adm_delsel_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const prodId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, prodId));
    if (!product) return;
    try {
      await ctx.editMessageText(
        `🗑️ <b>Delete Product</b>\n\nAre you sure you want to delete:\n\n<b>${product.emoji} ${product.name}</b>\n\nThis will also remove it from any active baskets.`,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "✅ Yes, Delete", callback_data: `adm_delconf_${prodId}` }],
              [{ text: "❌ Cancel", callback_data: "adm_delprod" }],
            ],
          },
        },
      );
    } catch {
      await ctx.reply(`🗑️ Delete ${product.emoji} ${product.name}?`, {
        reply_markup: {
          inline_keyboard: [
            [{ text: "✅ Yes, Delete", callback_data: `adm_delconf_${prodId}` }],
            [{ text: "❌ Cancel", callback_data: "adm_delprod" }],
          ],
        },
      });
    }
  });

  bot.action(/^adm_delconf_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery("🗑️ Product deleted.");
    if (!adminGuard(ctx)) return;
    const prodId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, prodId));
    if (!product) return;
    await db.delete(productsTable).where(eq(productsTable.id, prodId));
    try {
      await ctx.editMessageText(
        `✅ <b>${product.emoji} ${product.name}</b> has been deleted.`,
        { parse_mode: "HTML", ...adminKeyboard() },
      );
    } catch {
      await ctx.reply(`✅ ${product.emoji} ${product.name} deleted.`, { parse_mode: "HTML", ...adminKeyboard() });
    }
  });

  // ── Toggle Stock ──────────────────────────────────────────────────────────
  bot.action("adm_stock", async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const products = await db.select().from(productsTable).orderBy(productsTable.id);
    if (products.length === 0) { await ctx.answerCbQuery("No products yet."); return; }
    try {
      await ctx.editMessageText("🔧 <b>Toggle Stock Status</b>\n\nTap a product to toggle:", {
        parse_mode: "HTML",
        ...adminStockKeyboard(products),
      });
    } catch {
      await ctx.reply("🔧 Toggle Stock:", { parse_mode: "HTML", ...adminStockKeyboard(products) });
    }
  });

  bot.action(/^adm_tstock_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const prodId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, prodId));
    if (!product) return;
    await db.update(productsTable).set({ inStock: !product.inStock }).where(eq(productsTable.id, prodId));
    const products = await db.select().from(productsTable).orderBy(productsTable.id);
    try {
      await ctx.editMessageText(
        `🔧 <b>Toggle Stock</b>\n\n${product.emoji} ${product.name} → <b>${!product.inStock ? "✅ In Stock" : "❌ Out of Stock"}</b>`,
        { parse_mode: "HTML", ...adminStockKeyboard(products) },
      );
    } catch {
      await ctx.reply(`✅ ${product.emoji} ${product.name} toggled.`);
    }
  });

  // ── Merge Categories ──────────────────────────────────────────────────────
  bot.action("adm_merge", async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const categories = await db.select().from(categoriesTable).orderBy(categoriesTable.id);
    if (categories.length < 2) { await ctx.answerCbQuery("Need at least 2 categories to merge."); return; }
    ctx.session.step = "admin_merge_src";
    ctx.session.pendingMergeSourceId = undefined;
    try {
      await ctx.editMessageText(
        "🔀 <b>Merge Categories</b>\n\nWhich category do you want to <b>merge into another</b>?\n<i>(This category will be deleted after merging its products.)</i>",
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              ...categories.map((c) => [{ text: `${c.emoji} ${c.name}`, callback_data: `adm_mergesrc_${c.id}` }]),
              [{ text: "❌ Cancel", callback_data: "admin" }],
            ],
          },
        },
      );
    } catch {
      await ctx.reply("🔀 Pick the source category to merge:", {
        reply_markup: {
          inline_keyboard: categories.map((c) => [{ text: `${c.emoji} ${c.name}`, callback_data: `adm_mergesrc_${c.id}` }]),
        },
      });
    }
  });

  bot.action(/^adm_mergesrc_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const srcId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    ctx.session.pendingMergeSourceId = srcId;
    const [src] = await db.select().from(categoriesTable).where(eq(categoriesTable.id, srcId));
    const targets = await db.select().from(categoriesTable).where(ne(categoriesTable.id, srcId)).orderBy(categoriesTable.id);
    try {
      await ctx.editMessageText(
        `🔀 Merge <b>${src?.emoji} ${src?.name}</b> into which category?`,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              ...targets.map((c) => [{ text: `${c.emoji} ${c.name}`, callback_data: `adm_mergedst_${srcId}_${c.id}` }]),
              [{ text: "❌ Cancel", callback_data: "admin" }],
            ],
          },
        },
      );
    } catch {
      await ctx.reply("Pick target:", {
        reply_markup: {
          inline_keyboard: targets.map((c) => [{ text: `${c.emoji} ${c.name}`, callback_data: `adm_mergedst_${srcId}_${c.id}` }]),
        },
      });
    }
  });

  bot.action(/^adm_mergedst_(\d+)_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const srcId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    const dstId = parseInt((ctx.match as RegExpMatchArray)[2], 10);
    const [[src], [dst]] = await Promise.all([
      db.select().from(categoriesTable).where(eq(categoriesTable.id, srcId)),
      db.select().from(categoriesTable).where(eq(categoriesTable.id, dstId)),
    ]);
    await db.update(productsTable).set({ categoryId: dstId }).where(eq(productsTable.categoryId, srcId));
    await db.update(categoriesTable).set({ parentId: dstId }).where(eq(categoriesTable.parentId, srcId));
    await db.delete(categoriesTable).where(eq(categoriesTable.id, srcId));
    ctx.session.pendingMergeSourceId = undefined;
    try {
      await ctx.editMessageText(
        `✅ <b>Merged!</b>\n\nAll products from <b>${src?.emoji} ${src?.name}</b> have been moved to <b>${dst?.emoji} ${dst?.name}</b>, and the source category was deleted.`,
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "⬅️ Admin Panel", callback_data: "admin" }]] } },
      );
    } catch {
      await ctx.reply(`✅ Merged ${src?.name} → ${dst?.name}.`);
    }
  });

  // ── Pending Orders ────────────────────────────────────────────────────────
  bot.action("adm_pending", async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const orders = await db.select().from(ordersTable).where(eq(ordersTable.status, "waiting_payment")).orderBy(desc(ordersTable.createdAt));
    if (orders.length === 0) {
      try {
        await ctx.editMessageText("📋 <b>Pending Orders</b>\n\nNone right now. 🎉", {
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: [[{ text: "⬅️ Admin Panel", callback_data: "admin" }]] },
        });
      } catch {
        await ctx.reply("📋 No pending orders.");
      }
      return;
    }
    const buttons = orders.map((o) => [{
      text: `#${o.id} — ${gbp(o.totalPence)} — @${o.username ?? "unknown"} — ${new Date(o.createdAt).toLocaleDateString("en-GB")}`,
      callback_data: `adm_order_${o.id}`,
    }]);
    try {
      await ctx.editMessageText(`📋 <b>Pending Orders (${orders.length})</b>\n\nTap to view:`, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [...buttons, [{ text: "⬅️ Admin Panel", callback_data: "admin" }]] },
      });
    } catch {
      await ctx.reply(`📋 Pending (${orders.length})`, { parse_mode: "HTML", reply_markup: { inline_keyboard: buttons } });
    }
  });

  // ── All Orders ────────────────────────────────────────────────────────────
  bot.action("adm_allorders", async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const orders = await db.select().from(ordersTable).orderBy(desc(ordersTable.createdAt)).limit(20);
    if (orders.length === 0) {
      try {
        await ctx.editMessageText("📊 <b>All Orders</b>\n\nNo orders yet.", {
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: [[{ text: "⬅️ Admin Panel", callback_data: "admin" }]] },
        });
      } catch { await ctx.reply("No orders yet."); }
      return;
    }
    const statusEmoji: Record<string, string> = { waiting_payment: "⏳", paid: "✅", shipped: "🚚", cancelled: "❌" };
    const lines = orders.map((o) =>
      `${statusEmoji[o.status] ?? "❓"} <b>#${o.id}</b> — ${gbp(o.totalPence)} — @${o.username ?? "anon"} — ${new Date(o.createdAt).toLocaleDateString("en-GB")}`,
    );
    try {
      await ctx.editMessageText(`📊 <b>All Orders (last 20)</b>\n\n${lines.join("\n")}`, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "⬅️ Admin Panel", callback_data: "admin" }]] },
      });
    } catch {
      await ctx.reply(`📊 <b>All Orders</b>\n\n${lines.join("\n")}`, { parse_mode: "HTML" });
    }
  });

  // ── Order Detail ──────────────────────────────────────────────────────────
  bot.action(/^adm_order_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const orderId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    const [[order], items] = await Promise.all([
      db.select().from(ordersTable).where(eq(ordersTable.id, orderId)),
      db.select().from(orderItemsTable).where(eq(orderItemsTable.orderId, orderId)),
    ]);
    if (!order) return;
    const lines = items.map((i) => `• ${i.productName} ×${i.quantity} — ${gbp(i.pricePence * i.quantity)}`);
    const addressLine = order.deliveryAddress
      ? `\n📦 <b>Deliver to:</b>\n<code>${order.deliveryAddress}</code>\n`
      : "\n📦 <b>Deliver to:</b> <i>not provided</i>\n";
    const trackLine = order.trackingRef ? `\n📮 <b>Tracking:</b> <code>${order.trackingRef}</code>` : "";
    const text = `📦 <b>Order #${orderId}</b>
━━━━━━━━━━━━━━━
👤 @${order.username ?? "unknown"} (ID: ${order.userId})
📅 ${new Date(order.createdAt).toLocaleString("en-GB")}
💷 <b>${gbp(order.totalPence)}</b>  •  📊 ${order.status}
${addressLine}${trackLine}
<b>Items:</b>
${lines.join("\n")}`;
    try {
      await ctx.editMessageText(text, { parse_mode: "HTML", ...verifyOrderKeyboard(orderId) });
    } catch {
      await ctx.reply(text, { parse_mode: "HTML", ...verifyOrderKeyboard(orderId) });
    }
  });

  // ── Verify Payment ────────────────────────────────────────────────────────
  bot.action(/^adm_verify_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery("✅ Payment verified!");
    if (!adminGuard(ctx)) return;
    const orderId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId));
    if (!order) return;
    await db.update(ordersTable).set({ status: "paid", verifiedAt: new Date() }).where(eq(ordersTable.id, orderId));
    try {
      await ctx.editMessageText(`✅ <b>Order #${orderId} verified.</b> Customer notified.`, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🚚 Mark Shipped", callback_data: `adm_ship_${orderId}` }],
            [{ text: "⬅️ Pending Orders", callback_data: "adm_pending" }],
          ],
        },
      });
    } catch {
      await ctx.reply(`✅ Order #${orderId} verified.`);
    }
    try {
      await bot.telegram.sendMessage(order.chatId,
        `✅ <b>Payment Confirmed!</b>\n\nYour payment for Order <b>#${orderId}</b> has been verified.\n\n🎉 <b>3/3 confirmations — Payment confirmed!</b>\n\n📦 Your order is being processed and will be dispatched soon. Tracking info to follow.\n\nThanks for shopping with UncleTerpenes 🙌`,
        { parse_mode: "HTML" },
      );
    } catch { /* customer may have blocked */ }
  });

  // ── Mark Shipped — ask for tracking ref first ─────────────────────────────
  bot.action(/^adm_ship_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    if (!adminGuard(ctx)) return;
    const orderId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    ctx.session.pendingShipOrderId = orderId;
    ctx.session.step = "admin_ship_tracking";
    await ctx.reply(
      `🚚 <b>Mark Order #${orderId} as Shipped</b>\n\nEnter a <b>tracking reference</b> to send to the customer, or type <code>skip</code> to ship without one:`,
      {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "❌ Cancel", callback_data: `adm_order_${orderId}` }]] },
      },
    );
  });

  // ── Cancel Order (admin) ──────────────────────────────────────────────────
  bot.action(/^adm_cancel_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery("❌ Order cancelled.");
    if (!adminGuard(ctx)) return;
    const orderId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId));
    if (!order) return;
    await db.update(ordersTable).set({ status: "cancelled" }).where(eq(ordersTable.id, orderId));
    try {
      await ctx.editMessageText(`❌ <b>Order #${orderId} cancelled.</b>`, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "⬅️ Admin Panel", callback_data: "admin" }]] },
      });
    } catch { await ctx.reply(`❌ Order #${orderId} cancelled.`); }
    try {
      await bot.telegram.sendMessage(order.chatId,
        `❌ <b>Order #${orderId} Cancelled</b>\n\nYour order has been cancelled. If you think this is a mistake, please contact @UncleTerpene.`,
        { parse_mode: "HTML" },
      );
    } catch { /* ok */ }
  });

  // ── Text handler: admin multi-step flows ──────────────────────────────────
  bot.on("text", async (ctx, next) => {
    const userId = ctx.from?.id;
    if (!userId || !isAdmin(userId)) return next();
    const step = ctx.session.step;
    const text = ctx.message.text.trim();

    if (step === "admin_cat_name") {
      const match = text.match(/^(\p{Emoji_Presentation}|\p{Emoji}\uFE0F)\s*/u);
      const emoji = match ? match[0].trim() : "📦";
      const name = match ? text.slice(match[0].length).trim() : text;
      ctx.session.pendingCategory = { name, emoji };
      ctx.session.step = "admin_cat_type";
      await ctx.reply(
        `Category name: <b>${emoji} ${name}</b>\n\nIs this a top-level category or a subcategory inside another?`,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [
                { text: "📁 Top Level", callback_data: "adm_cat_toplevel" },
                { text: "📂 Subcategory", callback_data: "adm_cat_pickparent" },
              ],
              [{ text: "❌ Cancel", callback_data: "admin" }],
            ],
          },
        },
      );
      return;
    }

    if (step === "admin_prod_name") {
      const match = text.match(/^(\p{Emoji_Presentation}|\p{Emoji}\uFE0F)\s*/u);
      const emoji = match ? match[0].trim() : "🛍️";
      const name = match ? text.slice(match[0].length).trim() : text;
      ctx.session.pendingProduct = { ...ctx.session.pendingProduct, name, emoji };
      ctx.session.step = "admin_prod_price";
      await ctx.reply("💷 Enter the price per gram/unit in GBP (e.g. <code>5.00</code>):", {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "❌ Cancel", callback_data: "admin" }]] },
      });
      return;
    }

    if (step === "admin_prod_price") {
      const price = parseFloat(text.replace("£", "").trim());
      if (isNaN(price) || price <= 0) {
        await ctx.reply("⚠️ Invalid price. Enter a number like <code>5.00</code>:", { parse_mode: "HTML" });
        return;
      }
      ctx.session.pendingProduct = { ...ctx.session.pendingProduct, pricePence: Math.round(price * 100) };
      ctx.session.step = "admin_prod_unit";
      await ctx.reply(
        "📦 <b>How is this product sold?</b>",
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [
                { text: "⚖️ By the Gram", callback_data: "adm_unit_g" },
                { text: "📦 Per Unit", callback_data: "adm_unit_u" },
              ],
              [{ text: "❌ Cancel", callback_data: "admin" }],
            ],
          },
        },
      );
      return;
    }

    if (step === "admin_prod_desc") {
      const pending = ctx.session.pendingProduct;
      if (!pending?.categoryId || !pending.name || !pending.pricePence) {
        ctx.session.step = "admin";
        await ctx.reply("⚠️ Something went wrong. Please start again.", { ...adminKeyboard() });
        return;
      }
      const salesCount = Math.floor(Math.random() * 750) + 50;
      await db.insert(productsTable).values({
        categoryId: pending.categoryId,
        name: pending.name,
        description: text,
        pricePence: pending.pricePence,
        emoji: pending.emoji ?? "🛍️",
        inStock: true,
        unitType: pending.unitType ?? "g",
        salesCount,
      });
      ctx.session.step = "admin";
      ctx.session.pendingProduct = undefined;
      const unitLabel = (pending.unitType ?? "g") === "unit" ? "per unit" : "per gram";
      await ctx.reply(
        `✅ Product <b>${pending.emoji} ${pending.name}</b> (${gbp(pending.pricePence)} ${unitLabel}) added! 🛒 ${salesCount} sales seeded.`,
        { parse_mode: "HTML", ...adminKeyboard() },
      );
      return;
    }

    if (step === "admin_prod_img") {
      const prodId = ctx.session.pendingImgProductId;
      if (!prodId) return next();
      if (text.toLowerCase() === "remove") {
        await db.update(productsTable).set({ photoFileId: null }).where(eq(productsTable.id, prodId));
        ctx.session.step = "admin";
        ctx.session.pendingImgProductId = undefined;
        await ctx.reply("🗑️ <b>Image removed.</b>", { parse_mode: "HTML", ...adminKeyboard() });
        return;
      }
      await ctx.reply("⚠️ Please send a photo, or type <code>remove</code> to clear the image.", { parse_mode: "HTML" });
      return;
    }

    if (step === "admin_ship_tracking") {
      const orderId = ctx.session.pendingShipOrderId;
      if (!orderId) return next();
      const trackingRef = text.toLowerCase() === "skip" ? null : text;
      const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, orderId));
      if (!order) return next();
      await db.update(ordersTable).set({ status: "shipped", trackingRef }).where(eq(ordersTable.id, orderId));
      ctx.session.step = "admin";
      ctx.session.pendingShipOrderId = undefined;
      const trackingLabel = trackingRef
        ? `\n\n📮 <b>Tracking Reference:</b> <code>${trackingRef}</code>`
        : "";
      try {
        await ctx.reply(`🚚 <b>Order #${orderId} marked as shipped.</b>${trackingLabel}`, {
          parse_mode: "HTML",
          ...adminKeyboard(),
        });
      } catch { /* ok */ }
      try {
        const customerMsg = trackingRef
          ? `🚚 <b>Order #${orderId} Dispatched!</b>\n\nYour order is on its way — expect delivery within 1–2 working days.\n\n📮 <b>Tracking Reference:</b> <code>${trackingRef}</code>\n\nThanks for shopping with UncleTerpenes 🙌`
          : `🚚 <b>Order #${orderId} Dispatched!</b>\n\nYour order is on its way — expect delivery within 1–2 working days.\n\nTracking info will follow shortly.\n\nThanks for shopping with UncleTerpenes 🙌`;
        await bot.telegram.sendMessage(order.chatId, customerMsg, { parse_mode: "HTML" });
      } catch { /* ok */ }
      return;
    }

    return next();
  });

  // ── Photo handler: admin sets product image ───────────────────────────────
  bot.on("photo", async (ctx, next) => {
    const userId = ctx.from?.id;
    if (!userId || !isAdmin(userId)) return next();
    if (ctx.session.step !== "admin_prod_img") return next();
    const prodId = ctx.session.pendingImgProductId;
    if (!prodId) return next();

    const photos = (ctx.message as { photo: Array<{ file_id: string }> }).photo;
    const fileId = photos[photos.length - 1]!.file_id;

    const [product] = await db.select().from(productsTable).where(eq(productsTable.id, prodId));
    await db.update(productsTable).set({ photoFileId: fileId }).where(eq(productsTable.id, prodId));

    ctx.session.step = "admin";
    ctx.session.pendingImgProductId = undefined;

    await ctx.reply(
      `✅ <b>Image set for ${product?.emoji} ${product?.name}!</b>\n\nCustomers will see it when they tap the product.`,
      { parse_mode: "HTML", ...adminKeyboard() },
    );
  });
}
