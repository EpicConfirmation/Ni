import { Telegraf } from "telegraf";
import { eq, asc, desc } from "drizzle-orm";
import type { MyContext } from "../types";
import { db, supportMessagesTable } from "@workspace/db";
import { ADMIN_IDS, isAdmin } from "../config";

export function registerSupportHandlers(bot: Telegraf<MyContext>) {
  // ── Customer opens support ────────────────────────────────────────────────
  bot.action("support", async (ctx) => {
    await ctx.answerCbQuery();
    const userId = ctx.from?.id;
    if (!userId) return;

    const messages = await db
      .select()
      .from(supportMessagesTable)
      .where(eq(supportMessagesTable.userId, userId))
      .orderBy(asc(supportMessagesTable.createdAt))
      .limit(20);

    let historyText = "";
    if (messages.length > 0) {
      const lines = messages.map((m) => {
        const time = new Date(m.createdAt).toLocaleTimeString("en-GB", {
          hour: "2-digit",
          minute: "2-digit",
        });
        const sender = m.isAdminReply ? "👑 Admin" : "👤 You";
        return `<b>${sender}</b> [${time}]\n${m.message}`;
      });
      historyText = `\n\n${lines.join("\n\n")}`;
    }

    const text = `📞 <b>Contact Admin</b>
━━━━━━━━━━━━━━━${historyText}
━━━━━━━━━━━━━━━
💬 <b>Type your message below</b> and we'll get back to you as soon as possible.

📖 For common questions please check the ❓ FAQ first.`;

    ctx.session.step = "support_chat";

    try {
      await ctx.editMessageText(text, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "❌ Close", callback_data: "main" }]],
        },
      });
    } catch {
      await ctx.reply(text, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "❌ Close", callback_data: "main" }]],
        },
      });
    }
  });

  // ── Customer sends a support message ─────────────────────────────────────
  bot.on("text", async (ctx, next) => {
    if (ctx.session.step !== "support_chat") return next();
    if (isAdmin(ctx.from?.id ?? 0)) return next();

    const userId = ctx.from.id;
    const chatId = ctx.chat.id;
    const username = ctx.from.username ?? null;
    const message = ctx.message.text.trim();

    await db.insert(supportMessagesTable).values({
      userId,
      chatId,
      username,
      message,
      isAdminReply: false,
    });

    await ctx.reply(
      `✅ <b>Message sent!</b>\n\nOur team will reply here shortly.`,
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "💬 View Chat", callback_data: "support" }],
          ],
        },
      },
    );

    // Notify all admins
    for (const adminId of ADMIN_IDS) {
      try {
        await bot.telegram.sendMessage(
          adminId,
          `📬 <b>New support message</b>\n\n👤 @${username ?? "unknown"} (ID: <code>${userId}</code>)\n\n"${message}"`,
          {
            parse_mode: "HTML",
            reply_markup: {
              inline_keyboard: [
                [{ text: "💬 Reply", callback_data: `asuprep_${userId}` }],
                [{ text: "📋 View Conversation", callback_data: `asup_${userId}` }],
              ],
            },
          },
        );
      } catch {
        // Admin may not have started the bot
      }
    }
  });

  // ── Admin: support inbox ──────────────────────────────────────────────────
  bot.action("adm_support", async (ctx) => {
    await ctx.answerCbQuery();
    if (!isAdmin(ctx.from?.id ?? 0)) return;

    const rows = await db
      .selectDistinctOn([supportMessagesTable.userId], {
        userId: supportMessagesTable.userId,
        username: supportMessagesTable.username,
        message: supportMessagesTable.message,
        createdAt: supportMessagesTable.createdAt,
      })
      .from(supportMessagesTable)
      .where(eq(supportMessagesTable.isAdminReply, false))
      .orderBy(supportMessagesTable.userId, desc(supportMessagesTable.createdAt));

    if (rows.length === 0) {
      try {
        await ctx.editMessageText("💬 <b>Support Inbox</b>\n\nNo messages yet.", {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [[{ text: "⬅️ Admin Panel", callback_data: "admin" }]],
          },
        });
      } catch {
        await ctx.reply("💬 No support messages yet.");
      }
      return;
    }

    const buttons = rows.map((r) => [
      {
        text: `👤 @${r.username ?? r.userId} — "${r.message.slice(0, 30)}${r.message.length > 30 ? "…" : ""}"`,
        callback_data: `asup_${r.userId}`,
      },
    ]);

    try {
      await ctx.editMessageText(
        `💬 <b>Support Inbox (${rows.length} users)</b>\n\nTap a user to view their conversation:`,
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              ...buttons,
              [{ text: "⬅️ Admin Panel", callback_data: "admin" }],
            ],
          },
        },
      );
    } catch {
      await ctx.reply(`💬 <b>Support Inbox</b>`, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: buttons },
      });
    }
  });

  // ── Admin: view conversation with a user ─────────────────────────────────
  bot.action(/^asup_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    if (!isAdmin(ctx.from?.id ?? 0)) return;
    const userId = parseInt((ctx.match as RegExpMatchArray)[1], 10);

    const messages = await db
      .select()
      .from(supportMessagesTable)
      .where(eq(supportMessagesTable.userId, userId))
      .orderBy(asc(supportMessagesTable.createdAt))
      .limit(30);

    if (messages.length === 0) {
      await ctx.answerCbQuery("No messages found.");
      return;
    }

    const username = messages[0]?.username ?? String(userId);

    const lines = messages.map((m) => {
      const time = new Date(m.createdAt).toLocaleString("en-GB", {
        day: "2-digit",
        month: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      });
      const sender = m.isAdminReply ? "👑 Admin" : `👤 @${username}`;
      return `<b>${sender}</b> [${time}]\n${m.message}`;
    });

    const text = `💬 <b>Chat with @${username}</b>\n━━━━━━━━━━━━━━━\n${lines.join("\n\n")}`;

    try {
      await ctx.editMessageText(text, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✉️ Reply", callback_data: `asuprep_${userId}` },
              { text: "📥 Download Log", callback_data: `asuplog_${userId}` },
            ],
            [{ text: "⬅️ Inbox", callback_data: "adm_support" }],
          ],
        },
      });
    } catch {
      await ctx.reply(text, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✉️ Reply", callback_data: `asuprep_${userId}` },
              { text: "📥 Download Log", callback_data: `asuplog_${userId}` },
            ],
          ],
        },
      });
    }
  });

  // ── Admin: download chat log ──────────────────────────────────────────────
  bot.action(/^asuplog_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery("📥 Generating log...");
    if (!isAdmin(ctx.from?.id ?? 0)) return;
    const userId = parseInt((ctx.match as RegExpMatchArray)[1], 10);

    const messages = await db
      .select()
      .from(supportMessagesTable)
      .where(eq(supportMessagesTable.userId, userId))
      .orderBy(asc(supportMessagesTable.createdAt));

    if (messages.length === 0) {
      await ctx.reply("No messages to export.");
      return;
    }

    const username = messages[0]?.username ?? String(userId);

    const logLines = messages.map((m) => {
      const time = new Date(m.createdAt).toLocaleString("en-GB");
      const sender = m.isAdminReply ? "ADMIN" : `USER (@${username})`;
      return `[${time}] ${sender}: ${m.message}`;
    });

    const header = [
      `UncleTerpenes Shop — Support Chat Log`,
      `User: @${username} (ID: ${userId})`,
      `Exported: ${new Date().toLocaleString("en-GB")}`,
      `Messages: ${messages.length}`,
      `${"─".repeat(60)}`,
      "",
    ];

    const content = [...header, ...logLines].join("\n");
    const buffer = Buffer.from(content, "utf-8");

    await bot.telegram.sendDocument(
      ctx.chat!.id,
      { source: buffer, filename: `chat_log_${username}_${userId}.txt` },
      { caption: `📥 Chat log for @${username}` },
    );
  });

  // ── Admin: start reply flow ───────────────────────────────────────────────
  bot.action(/^asuprep_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    if (!isAdmin(ctx.from?.id ?? 0)) return;
    const userId = parseInt((ctx.match as RegExpMatchArray)[1], 10);

    const [lastMsg] = await db
      .select()
      .from(supportMessagesTable)
      .where(eq(supportMessagesTable.userId, userId))
      .orderBy(desc(supportMessagesTable.createdAt))
      .limit(1);

    ctx.session.step = "admin_reply";
    ctx.session.supportReplyUserId = userId;
    ctx.session.supportReplyChatId = Number(lastMsg?.chatId ?? userId);

    await ctx.reply(
      `✉️ <b>Replying to @${lastMsg?.username ?? userId}</b>\n\nType your reply message:`,
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "❌ Cancel", callback_data: `asup_${userId}` }]],
        },
      },
    );
  });

  // ── Admin text handler: send reply ────────────────────────────────────────
  bot.on("text", async (ctx, next) => {
    if (ctx.session.step !== "admin_reply") return next();
    if (!isAdmin(ctx.from?.id ?? 0)) return next();

    const targetUserId = ctx.session.supportReplyUserId;
    const targetChatId = ctx.session.supportReplyChatId;
    if (!targetUserId || !targetChatId) return next();

    const replyText = ctx.message.text.trim();

    await db.insert(supportMessagesTable).values({
      userId: targetUserId,
      chatId: targetChatId,
      username: null,
      message: replyText,
      isAdminReply: true,
    });

    ctx.session.step = "main";
    ctx.session.supportReplyUserId = undefined;
    ctx.session.supportReplyChatId = undefined;

    // Send to customer
    try {
      await bot.telegram.sendMessage(
        targetChatId,
        `👑 <b>Admin Reply</b>\n\n${replyText}\n\n<i>Reply via 📞 Contact Admin in the main menu.</i>`,
        { parse_mode: "HTML" },
      );
    } catch {
      // Customer may have blocked bot
    }

    await ctx.reply(
      `✅ <b>Reply sent!</b>`,
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "📋 View Conversation", callback_data: `asup_${targetUserId}` }]],
        },
      },
    );
  });
}
