import { Telegraf } from "telegraf";
import { eq, and } from "drizzle-orm";
import type { MyContext } from "../types";
import { basketKeyboard, paymentKeyboard } from "../keyboards";
import {
  db,
  basketItemsTable,
  productsTable,
  ordersTable,
  orderItemsTable,
} from "@workspace/db";
import { BTC_ADDRESS, gbp } from "../config";

async function getBasketWithProducts(userId: number) {
  const items = await db
    .select({
      basketId: basketItemsTable.id,
      quantity: basketItemsTable.quantity,
      productId: productsTable.id,
      productName: productsTable.name,
      productEmoji: productsTable.emoji,
      pricePence: productsTable.pricePence,
      unitType: productsTable.unitType,
      categoryId: productsTable.categoryId,
      inStock: productsTable.inStock,
    })
    .from(basketItemsTable)
    .innerJoin(productsTable, eq(basketItemsTable.productId, productsTable.id))
    .where(eq(basketItemsTable.userId, userId));
  return items;
}

function qtyDisplay(quantity: number, unitType: string): string {
  return unitType === "unit" ? `×${quantity}` : `${quantity}g`;
}

export function registerBasketHandlers(bot: Telegraf<MyContext>) {
  bot.action("basket", async (ctx) => {
    await ctx.answerCbQuery();
    const userId = ctx.from?.id;
    if (!userId) return;

    const items = await getBasketWithProducts(userId);

    if (items.length === 0) {
      try {
        await ctx.editMessageText(
          "🧺 <b>Your Basket</b>\n\nYour basket is empty. Browse the shop to add items!",
          { parse_mode: "HTML", ...basketKeyboard(false) },
        );
      } catch {
        await ctx.reply(
          "🧺 <b>Your Basket</b>\n\nYour basket is empty. Browse the shop to add items!",
          { parse_mode: "HTML", ...basketKeyboard(false) },
        );
      }
      return;
    }

    const totalPence = items.reduce(
      (sum, i) => sum + i.pricePence * i.quantity,
      0,
    );

    const lines = items.map(
      (i) =>
        `${i.productEmoji} ${i.productName} ${qtyDisplay(i.quantity, i.unitType)} — ${gbp(i.pricePence * i.quantity)}`,
    );

    const removeButtons = items.map((i) => [
      {
        text: `🗑️ Remove ${i.productEmoji} ${i.productName}`,
        callback_data: `brem_${i.basketId}`,
      },
    ]);

    const text = `🧺 <b>Your Basket</b>
━━━━━━━━━━━━━━━
${lines.join("\n")}
━━━━━━━━━━━━━━━
💷 Total: <b>${gbp(totalPence)}</b>`;

    const keyboard = {
      reply_markup: {
        inline_keyboard: [
          [{ text: "✅ Checkout", callback_data: "checkout" }],
          ...removeButtons,
          [{ text: "🗑️ Clear All", callback_data: "bclr" }],
          [{ text: "🛒 Shop", callback_data: "shop" }],
        ],
      },
    };

    try {
      await ctx.editMessageText(text, { parse_mode: "HTML", ...keyboard });
    } catch {
      await ctx.reply(text, { parse_mode: "HTML", ...keyboard });
    }
  });

  bot.action(/^brem_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery("🗑️ Item removed.");
    const basketId = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    await db.delete(basketItemsTable).where(eq(basketItemsTable.id, basketId));

    const userId = ctx.from?.id;
    if (!userId) return;
    const items = await getBasketWithProducts(userId);

    if (items.length === 0) {
      try {
        await ctx.editMessageText(
          "🧺 <b>Your Basket</b>\n\nYour basket is now empty.",
          { parse_mode: "HTML", ...basketKeyboard(false) },
        );
      } catch {
        await ctx.reply("🧺 Your basket is now empty.", { parse_mode: "HTML" });
      }
      return;
    }

    const totalPence = items.reduce(
      (sum, i) => sum + i.pricePence * i.quantity,
      0,
    );
    const lines = items.map(
      (i) =>
        `${i.productEmoji} ${i.productName} ${qtyDisplay(i.quantity, i.unitType)} — ${gbp(i.pricePence * i.quantity)}`,
    );
    const removeButtons = items.map((i) => [
      {
        text: `🗑️ Remove ${i.productEmoji} ${i.productName}`,
        callback_data: `brem_${i.basketId}`,
      },
    ]);

    const text = `🧺 <b>Your Basket</b>
━━━━━━━━━━━━━━━
${lines.join("\n")}
━━━━━━━━━━━━━━━
💷 Total: <b>${gbp(totalPence)}</b>`;

    try {
      await ctx.editMessageText(text, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "✅ Checkout", callback_data: "checkout" }],
            ...removeButtons,
            [{ text: "🗑️ Clear All", callback_data: "bclr" }],
            [{ text: "🛒 Shop", callback_data: "shop" }],
          ],
        },
      });
    } catch {
      await ctx.reply(text, { parse_mode: "HTML" });
    }
  });

  bot.action("bclr", async (ctx) => {
    await ctx.answerCbQuery("🗑️ Basket cleared.");
    const userId = ctx.from?.id;
    if (!userId) return;
    await db
      .delete(basketItemsTable)
      .where(eq(basketItemsTable.userId, userId));
    try {
      await ctx.editMessageText("🧺 <b>Your Basket</b>\n\nBasket cleared.", {
        parse_mode: "HTML",
        ...basketKeyboard(false),
      });
    } catch {
      await ctx.reply("🗑️ Basket cleared.", { parse_mode: "HTML" });
    }
  });

  // ── Step 1: Checkout — ask for delivery address ───────────────────────────
  bot.action("checkout", async (ctx) => {
    await ctx.answerCbQuery();
    const userId = ctx.from?.id;
    if (!userId) return;

    const items = await getBasketWithProducts(userId);
    if (items.length === 0) {
      await ctx.answerCbQuery("Your basket is empty!");
      return;
    }

    const totalPence = items.reduce(
      (sum, i) => sum + i.pricePence * i.quantity,
      0,
    );

    ctx.session.pendingCheckout = {
      totalPence,
      items: items.map((i) => ({
        productName: i.productName,
        productEmoji: i.productEmoji,
        pricePence: i.pricePence,
        quantity: i.quantity,
        unitType: i.unitType,
      })),
    };
    ctx.session.step = "awaiting_address";

    const orderLines = items.map(
      (i) =>
        `• ${i.productEmoji} ${i.productName} ${qtyDisplay(i.quantity, i.unitType)} — ${gbp(i.pricePence * i.quantity)}`,
    );

    const summaryText = `🧾 <b>Order Summary</b>
━━━━━━━━━━━━━━━
${orderLines.join("\n")}
━━━━━━━━━━━━━━━
💷 Total: <b>${gbp(totalPence)}</b>

📦 <b>Enter your full delivery address below</b>, including your name, house number, street, city, and postcode.

<i>Example:
John Smith
14 Baker Street
London
NW1 6XE</i>`;

    try {
      await ctx.editMessageText(summaryText, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "❌ Cancel", callback_data: "basket" }],
          ],
        },
      });
    } catch {
      await ctx.reply(summaryText, {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [{ text: "❌ Cancel", callback_data: "basket" }],
          ],
        },
      });
    }
  });

  // ── Step 2: Receive address, create order, show payment ───────────────────
  bot.on("text", async (ctx, next) => {
    if (ctx.session.step !== "awaiting_address") return next();

    const userId = ctx.from?.id;
    const chatId = ctx.chat?.id;
    if (!userId || !chatId) return next();

    const address = ctx.message.text.trim();

    if (address.length < 10) {
      await ctx.reply(
        "⚠️ That address looks too short. Please enter your full delivery address including name, street, city and postcode.",
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: "❌ Cancel", callback_data: "basket" }],
            ],
          },
        },
      );
      return;
    }

    const pending = ctx.session.pendingCheckout;
    if (!pending) {
      ctx.session.step = "main";
      await ctx.reply("Something went wrong. Please try checking out again.", {
        reply_markup: {
          inline_keyboard: [[{ text: "🧺 Basket", callback_data: "basket" }]],
        },
      });
      return;
    }

    ctx.session.step = "main";
    ctx.session.pendingCheckout = undefined;

    const [order] = await db
      .insert(ordersTable)
      .values({
        userId,
        chatId,
        username: ctx.from.username ?? null,
        totalPence: pending.totalPence,
        btcAddress: BTC_ADDRESS,
        deliveryAddress: address,
        status: "waiting_payment",
      })
      .returning();

    await db.insert(orderItemsTable).values(
      pending.items.map((i) => ({
        orderId: order.id,
        productName: i.productName,
        pricePence: i.pricePence,
        quantity: i.quantity,
      })),
    );

    await db
      .delete(basketItemsTable)
      .where(eq(basketItemsTable.userId, userId));

    const orderLines = pending.items.map(
      (i) =>
        `• ${i.productEmoji} ${i.productName} ${qtyDisplay(i.quantity, i.unitType)} — ${gbp(i.pricePence * i.quantity)}`,
    );

    const paymentText = `🧾 <b>Order #${order.id} — Payment Required</b>
━━━━━━━━━━━━━━━
${orderLines.join("\n")}
━━━━━━━━━━━━━━━
💷 Total: <b>${gbp(pending.totalPence)}</b>

📦 <b>Delivery to:</b>
<code>${address}</code>

💰 <b>Send BTC to the address below:</b>
<code>${BTC_ADDRESS}</code>

⚠️ Send the <b>exact GBP equivalent in BTC</b> at the time of payment.

⏳ <b>Status: Waiting for blockchain confirmation...</b>
<i>0/3 confirmations — your order will be processed once payment is verified.</i>

Once sent, press the button below and our team will confirm your payment manually.`;

    await ctx.reply(paymentText, {
      parse_mode: "HTML",
      ...paymentKeyboard(),
    });

    simulateBlockchainProgress(bot, chatId, order.id);
  });

  bot.action("payment_sent", async (ctx) => {
    await ctx.answerCbQuery("✅ Got it! We'll verify your payment shortly.");
    await ctx.reply(
      `✅ <b>Payment notification received!</b>\n\nOur team will verify your transaction on the blockchain shortly. You'll be notified here once confirmed.\n\n📞 If you have any issues, contact @UncleTerpene with your order number.`,
      { parse_mode: "HTML" },
    );
  });

  bot.action("cancel_order", async (ctx) => {
    await ctx.answerCbQuery("❌ Order cancelled.");
    ctx.session.step = "main";
    ctx.session.pendingCheckout = undefined;
    try {
      await ctx.editMessageText(
        "❌ <b>Order cancelled.</b>\n\nYour order has been cancelled. Feel free to browse the shop again.",
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "🛒 Shop", callback_data: "shop" }],
            ],
          },
        },
      );
    } catch {
      await ctx.reply("❌ Order cancelled.", { parse_mode: "HTML" });
    }
  });
}

function simulateBlockchainProgress(
  bot: Telegraf<MyContext>,
  chatId: number,
  orderId: number,
) {
  const stages = [
    { delay: 45000, confirmations: 1 },
    { delay: 90000, confirmations: 2 },
  ];

  for (const stage of stages) {
    setTimeout(async () => {
      try {
        await bot.telegram.sendMessage(
          chatId,
          `🔄 <b>Order #${orderId} — Blockchain Update</b>\n\n⛓️ ${stage.confirmations}/3 confirmations received...\n<i>Waiting for full confirmation before processing.</i>`,
          { parse_mode: "HTML" },
        );
      } catch {
        // Silently ignore
      }
    }, stage.delay);
  }
}
