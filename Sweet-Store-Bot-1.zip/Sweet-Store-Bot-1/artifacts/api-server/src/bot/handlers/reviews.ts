import { Telegraf } from "telegraf";
import type { MyContext } from "../types";
import { reviewsKeyboard } from "../keyboards";
import { FAKE_REVIEWS } from "../reviews";

function filteredReviews(star: number) {
  return star === 0 ? FAKE_REVIEWS : FAKE_REVIEWS.filter((r) => r.rating === star);
}

function buildReviewText(filter: number, page: number): string {
  const list = filteredReviews(filter);
  const review = list[page];
  if (!review) return "No reviews found.";
  const stars = "⭐".repeat(review.rating);
  const filterLabel =
    filter === 0 ? "All Reviews" : `${"⭐".repeat(filter)} Reviews`;
  return `⭐ <b>Customer Reviews — ${filterLabel}</b>
━━━━━━━━━━━━━━━
Review ${page + 1} of ${list.length}

${stars}  ${review.date}

"${review.text}"

━━━━━━━━━━━━━━━
Overall Rating: ★4.94 (164 reviews)`;
}

export function registerReviewHandlers(bot: Telegraf<MyContext>) {
  bot.action("reviews", async (ctx) => {
    await ctx.answerCbQuery();
    const filter = 0;
    const page = 0;
    ctx.session.reviewPage = page;
    const text = buildReviewText(filter, page);
    try {
      await ctx.editMessageText(text, {
        parse_mode: "HTML",
        ...reviewsKeyboard(filter, page, filteredReviews(filter).length),
      });
    } catch {
      await ctx.reply(text, {
        parse_mode: "HTML",
        ...reviewsKeyboard(filter, page, filteredReviews(filter).length),
      });
    }
  });

  // Handles: rev_{filter}_{page}  e.g. rev_5_0, rev_0_3, rev_4_1
  bot.action(/^rev_(\d+)_(\d+)$/, async (ctx) => {
    await ctx.answerCbQuery();
    const filter = parseInt((ctx.match as RegExpMatchArray)[1], 10);
    const page = parseInt((ctx.match as RegExpMatchArray)[2], 10);
    ctx.session.reviewPage = page;
    const list = filteredReviews(filter);
    const safePage = Math.min(page, Math.max(0, list.length - 1));
    const text = buildReviewText(filter, safePage);
    try {
      await ctx.editMessageText(text, {
        parse_mode: "HTML",
        ...reviewsKeyboard(filter, safePage, list.length),
      });
    } catch {
      await ctx.reply(text, {
        parse_mode: "HTML",
        ...reviewsKeyboard(filter, safePage, list.length),
      });
    }
  });
}
