# UncleTerpenes Shop Bot

A 24/7 Telegram shop bot for UncleTerpenes with categories, products, basket, crypto payments (BTC), admin panel, fake blockchain confirmations, and customer reviews.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server + Telegram bot (port 5000 in dev)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required env: `TELEGRAM_BOT_TOKEN` — from @BotFather
- Required env: `ADMIN_IDS` — comma-separated Telegram user IDs for admins (e.g. `7236853161`)
- Required env: `BTC_ADDRESS` — Bitcoin payment address
- Required env: `COMMUNITY_CHAT` — Telegram community URL

## UptimeRobot Ping

Point UptimeRobot at: `https://<your-replit-domain>/api/healthz`
This returns `{"status":"ok"}` and keeps the bot alive 24/7.

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- Bot: Telegraf v4
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server/src/bot/` — all Telegram bot code
- `artifacts/api-server/src/bot/handlers/` — per-feature handlers (main, shop, basket, admin, reviews)
- `artifacts/api-server/src/bot/keyboards.ts` — all inline keyboard builders
- `artifacts/api-server/src/bot/config.ts` — admin IDs, BTC address, helpers
- `artifacts/api-server/src/bot/reviews.ts` — fake review data
- `lib/db/src/schema/shop.ts` — full DB schema (categories, products, baskets, orders)

## Architecture decisions

- Bot uses long-polling (not webhooks) so it works in any hosting environment without public HTTPS setup.
- Prices stored in pence (integer) to avoid floating point issues; displayed as GBP with `gbp()` helper.
- Admin state machine uses Telegraf session (in-memory) for multi-step flows like adding products.
- Fake blockchain confirmations are simulated with `setTimeout` sending progress messages at 45s and 90s.
- Admin manually verifies payment → updates order status → notifies customer via `bot.telegram.sendMessage`.

## Product

- **Main menu**: Store branding, stats, shipping info
- **Shop**: Browse categories → products → add to basket
- **Basket**: View, remove items, checkout
- **Payments**: BTC address shown, fake blockchain confirmation progress, admin manual verify
- **Reviews**: Paginated fake reviews with UK delivery praise
- **FAQ**: Common questions answered inline
- **Admin Panel** (admin-only): Add categories, add products, toggle stock, view/verify orders, mark shipped

## User preferences

- Shop name: UncleTerpenes Shop
- Admin: @UncleTerene (ID: 7236853161)
- BTC address: bc1pjy8a949q20s9nraxaw4xvqyr3qmutc76eewrthvy5pjxc8u8yykq93zjnf
- Community chat: https://t.me/NLsweetsUK2UK
- Currency: GBP, ships UK→UK, Mon–Fri, cut-off 2PM

## Gotchas

- Always run `pnpm --filter @workspace/db run push` after changing `lib/db/src/schema/shop.ts`
- Admin panel text input steps rely on in-memory session; if bot restarts mid-flow the step resets
- `bot.launch({ dropPendingUpdates: true })` prevents replaying old messages on restart

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
