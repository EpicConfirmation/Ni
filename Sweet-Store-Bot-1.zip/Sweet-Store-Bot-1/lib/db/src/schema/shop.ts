import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  bigint,
  type AnyPgColumn,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";

export const categoriesTable = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  emoji: text("emoji").notNull().default("📦"),
  parentId: integer("parent_id").references((): AnyPgColumn => categoriesTable.id, {
    onDelete: "set null",
  }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const productsTable = pgTable("products", {
  id: serial("id").primaryKey(),
  categoryId: integer("category_id")
    .notNull()
    .references(() => categoriesTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  pricePence: integer("price_pence").notNull(),
  emoji: text("emoji").notNull().default("🛍️"),
  inStock: boolean("in_stock").notNull().default(true),
  photoFileId: text("photo_file_id"),
  unitType: text("unit_type").notNull().default("g"),
  salesCount: integer("sales_count").notNull().default(100),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const basketItemsTable = pgTable("basket_items", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number" }).notNull(),
  productId: integer("product_id")
    .notNull()
    .references(() => productsTable.id, { onDelete: "cascade" }),
  quantity: integer("quantity").notNull().default(1),
});

export const ordersTable = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number" }).notNull(),
  chatId: bigint("chat_id", { mode: "number" }).notNull(),
  username: text("username"),
  totalPence: integer("total_pence").notNull(),
  btcAddress: text("btc_address").notNull(),
  deliveryAddress: text("delivery_address"),
  status: text("status").notNull().default("waiting_payment"),
  notes: text("notes"),
  trackingRef: text("tracking_ref"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  verifiedAt: timestamp("verified_at"),
});

export const orderItemsTable = pgTable("order_items", {
  id: serial("id").primaryKey(),
  orderId: integer("order_id")
    .notNull()
    .references(() => ordersTable.id, { onDelete: "cascade" }),
  productName: text("product_name").notNull(),
  pricePence: integer("price_pence").notNull(),
  quantity: integer("quantity").notNull(),
});

export const supportMessagesTable = pgTable("support_messages", {
  id: serial("id").primaryKey(),
  userId: bigint("user_id", { mode: "number" }).notNull(),
  chatId: bigint("chat_id", { mode: "number" }).notNull(),
  username: text("username"),
  message: text("message").notNull(),
  isAdminReply: boolean("is_admin_reply").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// ── Relations ─────────────────────────────────────────────────────────────────

export const categoriesRelations = relations(categoriesTable, ({ many, one }) => ({
  products: many(productsTable),
  subcategories: many(categoriesTable, { relationName: "parentChild" }),
  parent: one(categoriesTable, {
    fields: [categoriesTable.parentId],
    references: [categoriesTable.id],
    relationName: "parentChild",
  }),
}));

export const productsRelations = relations(productsTable, ({ one }) => ({
  category: one(categoriesTable, {
    fields: [productsTable.categoryId],
    references: [categoriesTable.id],
  }),
}));

export const ordersRelations = relations(ordersTable, ({ many }) => ({
  items: many(orderItemsTable),
}));

export const orderItemsRelations = relations(orderItemsTable, ({ one }) => ({
  order: one(ordersTable, {
    fields: [orderItemsTable.orderId],
    references: [ordersTable.id],
  }),
}));

// ── Zod schemas ───────────────────────────────────────────────────────────────

export const insertCategorySchema = createInsertSchema(categoriesTable).omit({
  id: true,
  createdAt: true,
});
export const insertProductSchema = createInsertSchema(productsTable).omit({
  id: true,
  createdAt: true,
});

export type Category = typeof categoriesTable.$inferSelect;
export type Product = typeof productsTable.$inferSelect;
export type Order = typeof ordersTable.$inferSelect;
export type OrderItem = typeof orderItemsTable.$inferSelect;
export type BasketItem = typeof basketItemsTable.$inferSelect;
export type SupportMessage = typeof supportMessagesTable.$inferSelect;
